import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JPanel;

public class PanelBotones extends JPanel  implements ActionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Color color;
	private JButton bcolor;
	private JButton perro;
	private JButton gato;
	private JButton borrego;
	private JPanel panel;
	
	public PanelBotones() {
		setVisible(true);
		setLayout(new BorderLayout());
		setSize(100,500);
		
		
		bcolor=new JButton("COLOR");
		perro=new JButton("PERRO");
		gato=new JButton("GATO");
		borrego=new JButton("BORREGO");
		panel=new JPanel();
		
		bcolor.addActionListener(this);
		perro.addActionListener(this);
		gato.addActionListener(this);
		borrego.addActionListener(this);
		
		panel.setLayout(new GridLayout(4,1));
		panel.add(bcolor);
		panel.add(perro);
		panel.add(gato);
		panel.add(borrego);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
		if(e.getSource()==bcolor) {
			color=JColorChooser.showDialog(PanelBotones.this,"ELIGE",Color.black);
		}
		
		if(e.getSource()==perro) {
			
		}
		
		if(e.getSource()==gato) {
			
		}
		if(e.getSource()==borrego) {
			
		}
		
	}

}
