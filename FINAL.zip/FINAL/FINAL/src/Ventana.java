import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class Ventana extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	PanelBotones pBotones=new PanelBotones();
	PanelDibujo pDibujo=new PanelDibujo() ;
	
	private JMenuBar bar;
	private JMenu menu;
	private JMenuItem guardar;
	private JMenuItem abrir;
	
	private Color color;
	private JButton bcolor;
	private JButton perro;
	private JButton gato;
	private JButton borrego;
	private JPanel panel;
	private JPanel panelPrincipal;
	
	
	public Ventana() {
		setSize(1000,1000);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new BorderLayout());
		
		pDibujo=new PanelDibujo();
		pBotones=new PanelBotones();
		
		bar=new JMenuBar();
		menu=new JMenu("ARCHIVO");
		guardar=new JMenuItem("GUARDAR");
		abrir=new JMenuItem("ABRIR");
		
		bar.add(menu);
		menu.add(guardar);
		menu.add(abrir);
		
		setJMenuBar(bar);
		
		bar.setLayout(new BorderLayout());
		
		
		bcolor=new JButton("COLOR");
		perro=new JButton("PERRO");
		gato=new JButton("GATO");
		borrego=new JButton("BORREGO");
		panel=new JPanel();
		
		bcolor.addActionListener(this);
		perro.addActionListener(this);
		gato.addActionListener(this);
		borrego.addActionListener(this);
		
		panel.setLayout(new GridLayout(4,1));
		panel.add(bcolor);
		panel.add(perro);
		panel.add(gato);
		panel.add(borrego);
		
		panelPrincipal.add(panel);
			
		add(panelPrincipal,BorderLayout.CENTER);
		

	}


		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if(e.getSource()==bcolor) {
				color=JColorChooser.showDialog(Ventana.this,"ELIGE",Color.black);
			}
			
			if(e.getSource()==perro) {
				
			}
			
			if(e.getSource()==gato) {
				
			}
			if(e.getSource()==borrego) {
				
			}
			
		}
	
}
