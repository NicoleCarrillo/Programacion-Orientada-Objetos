import java.awt.BorderLayout;

import javax.swing.JPanel;

public class PanelDibujo extends JPanel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PanelDibujo() {
		setVisible(true);
		setLayout(new BorderLayout());
		//setSize(200,500);
	}

}
