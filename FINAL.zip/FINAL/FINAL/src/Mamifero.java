
public class Mamifero {

}
