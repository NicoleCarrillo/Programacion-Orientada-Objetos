package pp;

import java.awt.Color;
import java.awt.Graphics;

public abstract class Mamiferos {
	protected int x;
	protected int y;
	protected int ancho;
	protected int alto;
	protected Color color;
	protected Graphics g;
	
	public Mamiferos(int xINICIAL, int yINICIAL, int XFINAL, int YFINAL, Color color) {
	
	}
	
	
	public void dibujar(Graphics g) {
		g.setColor(color);
		g.fillOval(x,y, ancho, alto); //cara
		g.fillRect(x+100, y+100, ancho+100, alto+100);//cuerpo
		g.fillRect(x+100, y+200, ancho+100, alto+200);//patas
		g.fillRect(x+100, y+200, ancho+100, alto+200);//patas
		g.fillRect(x+500, y+500, ancho+10, alto+20);//orejas
		g.fillRect(x+700, y+700, ancho+10, alto+20);//orejas
	}
}
