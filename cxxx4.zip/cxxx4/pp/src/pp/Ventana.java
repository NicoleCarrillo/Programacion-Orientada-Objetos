package pp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class Ventana extends JFrame implements ActionListener, MouseListener, MouseMotionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JMenuBar barra;
	private JMenu menu;
	private JMenuItem guardar;
	private JMenuItem cargar;

	private JPanel panelPrincipal;
	private JFileChooser chooser;
	private JPanel panelBotones;
	private JButton colores;
	private JButton perro;
	private JButton gato;
	private JButton borrego;
	private Color color=Color.BLUE;


	private int XFINAL;
	private int YFINAL;
	private int xINICIAL;
	private int yINICIAL;

	public ArrayList <Mamiferos> lista=new ArrayList<Mamiferos>();

	public Ventana() {
		addMouseListener(this);
		addMouseMotionListener(this);
		setVisible(true);
		setSize(1000,1000);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		panelPrincipal=new JPanel();
		panelBotones=new JPanel();
		//chooser=new JFileChooser();

		barra=new JMenuBar();
		menu= new JMenu("ARCHIVO");
		guardar= new JMenuItem("GUARDAR");
		cargar= new JMenuItem("ABRI");

		barra.add(menu);
		menu.add(guardar);
		menu.add(cargar);

		colores=new JButton("color");
		perro=new JButton("perro");
		gato=new JButton("gato");
		borrego=new JButton("borrego");


		panelBotones.setLayout(new GridLayout(4,1));
		panelBotones.add(colores);
		panelBotones.add(perro);
		panelBotones.add(gato);
		panelBotones.add(borrego);

		colores.addActionListener(this);
		guardar.addActionListener(this);
		cargar.addActionListener(this);
		perro.addActionListener(this);
		gato.addActionListener(this);
		borrego.addActionListener(this);
		add(panelPrincipal,BorderLayout.CENTER);
		add(panelBotones,BorderLayout.WEST);
		setJMenuBar(barra);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==colores) {
			color=JColorChooser.showDialog(Ventana.this,"elige" ,Color.CYAN );
			//panelPrincipal.setBackground(color);
		}
		if (e.getSource()==perro){
			final int perrito=1;
			lista.add(new Perro(xINICIAL,yINICIAL, XFINAL, YFINAL, color));
		}

		if (e.getSource()==gato){
			final int gatito=2;
			lista.add(new Gato(xINICIAL,yINICIAL, XFINAL, YFINAL, color));
		}

		if (e.getSource()==borrego){
			final int borrego=3;
			lista.add(new Borrego(xINICIAL,yINICIAL, XFINAL, YFINAL, color));
		}

		if (e.getSource()==guardar){
			int resultado = chooser.showSaveDialog(this);
			/*if(resultado == JFileChooser.APPROVE_OPTION) {
				System.out.println(chooser.getSelectedFile().getPath());

				FileWriter fw;
				try {
					fw = new FileWriter(chooser.getSelectedFile().getPath());
					BufferedWriter bw = new BufferedWriter(fw);
					PrintWriter pw = new PrintWriter(bw);
					//pw.println(lista);
					pw.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}*/
		}

		if (e.getSource()==cargar){
			int resultado = chooser.showOpenDialog(this);

			if(resultado == JFileChooser.APPROVE_OPTION) {
				System.out.println(chooser.getSelectedFile().getPath());

				FileReader fr;
				try {
					fr = new FileReader(chooser.getSelectedFile().getPath());
					BufferedReader br = new BufferedReader(fr);
					//String linea=br.readLine();
					br.close();
				} catch (FileNotFoundException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}}}
		}


		public void paint(Graphics g) {
			super.paint(g);
			dibujar(g);
		}

		public void dibujar(Graphics g) {//metodo para revisar que funciona los mouse 
			g.setColor(color);
			g.fillOval(xINICIAL,yINICIAL, XFINAL, YFINAL);
			g.fillRect(xINICIAL+100, yINICIAL+100, XFINAL+100, YFINAL+100);
			g.fillRect(xINICIAL+100, yINICIAL+200, XFINAL+100, YFINAL+200);
			g.fillRect(xINICIAL+100, yINICIAL+200, XFINAL+100, YFINAL+200);
		}

		@Override
		public void mousePressed(MouseEvent e) {
			System.out.print("h");
			xINICIAL=e.getX();
			System.out.println(xINICIAL);
			yINICIAL=e.getY();
			System.out.println(yINICIAL);
		}

		@Override
		public void mouseDragged(MouseEvent e) {
			// TODO Auto-generated method stub
			XFINAL=e.getX()-this.xINICIAL;
			System.out.println(XFINAL);
			YFINAL=e.getY()-this.yINICIAL;
			//this.repaint();
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			XFINAL=e.getX()-this.xINICIAL;
			System.out.println(XFINAL);
			YFINAL=e.getY()-this.yINICIAL;
			this.repaint();

		}

		@Override
		public void mouseMoved(MouseEvent arg0) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseClicked(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseEntered(MouseEvent e) {
			// TODO Auto-generated method stub

		}

		@Override
		public void mouseExited(MouseEvent e) {
			// TODO Auto-generated method stub

		}
	}
